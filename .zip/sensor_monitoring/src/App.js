import { Route, Routes, useLocation} from "react-router-dom";
import Login from "./components/login";
import Dashboard from "./components/dashboard";

function App() {
  const location = useLocation();
  return (
    <>
      <Routes>
        <Route path="/*" element={<Dashboard  pathName={location.pathname}/>} />
        <Route path="/login" element={<Login/>} />
      </Routes>
    </>
  );
}

export default App;
