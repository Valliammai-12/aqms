import React from "react";
import { useNavigate } from "react-router-dom";

function Building() {
  const navigate = useNavigate();
  return (
    <div className="Building body">
      <div className="buildHead">Air Quality Monitoring System</div>
      <div className="buildCont">
        <div
          className="floorCard"
          onClick={() => {
            navigate("/ground-floor");
          }}
        >
          Ground Floor
        </div>
        <div
          className="floorCard"
          onClick={() => {
            navigate("/first-floor");
          }}
        >
          First Floor
        </div>
        <div
          className="floorCard"
          onClick={() => {
            navigate("/second-floor");
          }}
        >
          Second Floor
        </div>
        <div
          className="floorCard"
          onClick={() => {
            navigate("/third-floor");
          }}
        >
          Third Floor
        </div>
      </div>
    </div>
  );
}

export default Building;
