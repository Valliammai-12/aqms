import React from 'react'
import Profile from '../images/profile.png'

function DashHead() {
  return (
    <div className='DashHead'>
        <div className="welcome">
            Welcome back!
        </div>
        <div className="user">
            <img src={Profile} alt="" />
            <p>Valli</p>
        </div>
    </div>
  )
}

export default DashHead