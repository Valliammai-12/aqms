import React, {useState} from 'react'
// import building from '../images/building.png'
import dashboard from '../images/dashboard.png'
import home from '../images/home.png'
import homeActive from '../images/homeactive.png'
import building from '../images/building.png'
import buildingActive from '../images/buildingactive.png'
import { useNavigate } from "react-router-dom";

function Dashlink(props) {
  const pathName = props.pathName;
    const [isHome, setIsHome] = useState(pathName === "/"? true: false);
    const [isFloorOne, setIsFloorOne] = useState(pathName !== "/"? true: false);
    const navigate = useNavigate();
  return (
    <div className='dashlink'>
        <div className="dash" onClick={() => {
            navigate("/");
          }}>
            <img src={dashboard} alt="img"/>
            <p>Dashboard</p>
        </div>
        <div className={!isHome? "linkItem": "linkItem bgblue"}  onClick={()=>{setIsHome(true); setIsFloorOne(false); navigate("/");}}>
            <img src={!isHome ? home : homeActive} alt="img"/>
            <p className={!isHome? "colorGrey" : "colorWhite"}>Home</p>
        </div>
        <div className={!isFloorOne? "linkItem": "linkItem bgblue"} onClick={()=>{setIsHome(false); setIsFloorOne(true); navigate("/building");}}>
            <img src={!isFloorOne ? building : buildingActive} alt="img"/>
            <p className={!isFloorOne? "colorGrey" : "colorWhite"}>Building</p>
        </div>
    </div>
  )
}

export default Dashlink