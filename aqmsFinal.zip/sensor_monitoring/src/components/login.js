import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [iserror, setIserror] = useState(false);
  const navigate = useNavigate();

  const handleLogin = () => {
    const payload = {
      email,
      password,
    };

    fetch('api/user/login', {
      method: "POST",
      body: JSON.stringify(payload),
      headers: {
        // 'Authorization': `bearer ${token}`,
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.status === 200) {
          const token = data.token;
          if (token) {
            localStorage.setItem("token", token);
            navigate("/");
          }
        }
        if (data.status === 400) {
          setIserror(true);
          setError(data.message);
        }
      })
      .catch(function (error) {
        setIserror(true);
        setError(error);
      });
  };
  
  return (
    <div className="login">
      <div className="container">
        <div className="info">
          <h2>Welcome Back</h2>
          <p>Enter your credentials to access your account</p>
        </div>
        <div className="loginForm">
          <input
            type="email"
            id="email"
            placeholder="Enter your email"
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />
          {iserror ? <p className="error">*{error}</p> : ""}
          <button onClick={handleLogin}>Sign in</button>
        </div>
      </div>
    </div>
  );
}

export default Login;
