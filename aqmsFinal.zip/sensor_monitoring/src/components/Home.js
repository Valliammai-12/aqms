import React,{useEffect, useState} from "react";
import {Chart, ArcElement, Tooltip, Legend} from 'chart.js';
import {Doughnut} from "react-chartjs-2"

Chart.register(ArcElement, Tooltip, Legend);

function Home() {

    const temp = {
        labels: ['C', 'CO2', 'O2', 'SO2', 'CO'],
        datasets:[{
            label: '--',
            data: [0,0,0,0,0],
            backgroundColor:['green','pink','black','orange', 'yellow'],
            borderColor: ['green','pink','black','orange', 'yellow']
        }]
    }
    const token = localStorage.getItem("token");
    const [groundData, setGroundData] = useState(temp)
    const [firstData, setFirstData] = useState(temp)
    const [secondData, setSecondData] = useState(temp)
    const [thirdData, setThirdData] = useState(temp)
    const getData = (data, label)=>{
        return {
            labels: ['C', 'CO2', 'O2', 'SO2', 'CO'],
            datasets:[{
                label: label,
                data: data,
                backgroundColor:['green','pink','black','orange', 'yellow'],
                borderColor: ['green','pink','black','orange', 'yellow']
            }]
        }
    }

    useEffect(()=>{
        getSensorData('ground-floor','Ground Floor', setGroundData);
        getSensorData('first-floor','First Floor', setFirstData);
        getSensorData('second-floor','Second Floor', setSecondData);
        getSensorData('third-floor','Third Floor', setThirdData);
      // eslint-disable-next-line
    },[])

    const getSensorData = (name,lable, setSensorData)=>{
        const payload = {
          name
        };
        fetch(`api/user/get-sensors`, {
        method: "POST",
        body: JSON.stringify(payload),
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
           const sendata = [data.sensor.carbon,data.sensor.co2,data.sensor.oxygen,data.sensor.so2,data.sensor.co]
           data = getData(sendata, lable);
          setSensorData(data);
        })
        .catch((error) => {
          return(error)
        });
    }

    
    

    const options = {
        
    }

    const getTextCenter=(data)=>{
        const textCenter ={
            id: 'textCenter',
            beforeDatasetsDraw(chart, args, pluginOptions){
                const {ctx, data} = chart;
                ctx.save();
                ctx.font = "bolder 20px san-serif";
                ctx.fillStyle = "black";
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText(data.datasets[0].label, chart.getDatasetMeta(0).data[0].x, chart.getDatasetMeta(0).data[0].y);
            }
        }
        return textCenter
    }
   

  return (
    <div className="Home body">
      <div className="piCont">
        <Doughnut
        data={groundData}
        options={options}
        plugins={[getTextCenter(groundData)]}
        ></Doughnut>
      </div>
      <div className="piCont">
        <Doughnut
        data={firstData}
        options={options}
        plugins={[getTextCenter(firstData)]}
        ></Doughnut>
      </div>
      <div className="piCont">
        <Doughnut
        data={secondData}
        options={options}
        plugins={[getTextCenter(secondData)]}
        ></Doughnut>
      </div>
      <div className="piCont">
        <Doughnut
        data={thirdData}
        options={options}
        plugins={[getTextCenter(thirdData)]}
        ></Doughnut>
      </div>
    </div>
  );
}

export default Home;
