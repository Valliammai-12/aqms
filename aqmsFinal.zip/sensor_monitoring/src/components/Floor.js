import React,{useEffect, useState} from "react";
import CO2 from "../images/co2.png";
import CO from "../images/gas-detector.png";
import O2 from "../images/oxygen-tank.png";
import SO2 from "../images/so2.png";
import Carbon from "../images/coal.png";

function Floor(props) {
  const pathName = props.pathName;
  const token = localStorage.getItem("token");
  const [sensorData, setSensorData] = useState([])
  let page;
  if(pathName === "/ground-floor") page = "Ground Floor"
  if(pathName === "/first-floor") page = "First Floor";
  if(pathName === "/second-floor") page = "Second Floor";
  if(pathName === "/third-floor") page = "Third Floor";

  useEffect(()=>{
      const payload = {
        name: pathName.slice(1,),
      };
      fetch(`api/user/get-sensors`, {
      method: "POST",
      body: JSON.stringify(payload),
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setSensorData(data.sensor);
      })
      .catch((error) => {
        return(error)
      });
    // eslint-disable-next-line
  },[])

  useEffect(()=>{
    const interval = setInterval(() => {
      const payload = {
        name: pathName.slice(1,),
      };
      fetch(`api/user/get-sensors`, {
      method: "POST",
      body: JSON.stringify(payload),
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setSensorData(data.sensor);
      })
      .catch((error) => {
        return(error)
      });
    }, 10000);
  
    return () => clearInterval(interval);
    // eslint-disable-next-line
  },[])


  return (
    <div className="body">
      <div className="buildHead">{`Sensor Value ${page}`}</div>
      <div className="floorCont">
        <div className="dataCard">
          <p>Carbon</p>
          <div className="value">
            <img src={Carbon} alt="" />
            <div id="data">{sensorData.carbon}</div>
          </div>
        </div>
        <div className="dataCard">
          <p>Carbon Dioxide</p>
          <div className="value">
            <div className="value">
              <img src={CO2} alt="" />
              <div id="data">{sensorData.co2}</div>
            </div>
          </div>
        </div>
        <div className="dataCard">
          <p>Oxygen</p>
          <div className="value">
            <img src={O2} alt="" />
            <div id="data">{sensorData.oxygen}</div>
          </div>
        </div>
        <div className="dataCard">
          <p>Sulfur Dioxide</p>
          <div className="value">
            <img src={SO2} alt="" />
            <div id="data">{sensorData.so2}</div>
          </div>
        </div>
        <div className="dataCard">
          <p>Carbon Monoxide</p>
          <div className="value">
            <img src={CO} alt="" />
            <div id="data">{sensorData.co}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Floor;
