import React from 'react'
import Building from './Building'
import DashHead from './DashHead'
import Home from './Home'
import Floor from './Floor'

function Dashbody(props) {
  const pathName = props.pathName;
  console.log(pathName);
  return (
    <div className='dashbody'>
      <DashHead />
      {pathName === "/" ? <Home /> : null}
      {pathName === "/building" ? <Building /> : null}
      {pathName === "/ground-floor" || pathName ==="/first-floor" || pathName ==="/second-floor" || pathName ==="/third-floor" ? <Floor pathName = {pathName} /> : null}
    </div>
  )
}

export default Dashbody