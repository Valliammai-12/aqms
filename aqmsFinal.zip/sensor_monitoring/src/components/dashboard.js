import React, {useEffect}from 'react'
import { useNavigate } from "react-router-dom";
import Dashlinks from './dashlink'
import Dashbody from './dashbody'
import './dashboard.css'

function Dashboard(props) {
  const pathName = props.pathName;
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
    // eslint-disable-next-line
  }, []);
  return (
    <div className='dashboard'>
        <Dashlinks pathName={pathName}/>
        <Dashbody pathName={pathName}/>
    </div>
  )
}

export default Dashboard